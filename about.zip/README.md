# Mahgiiban Internship Portfolio V2

Plain HTML/CSS/JavaScript. Open index.html to test locally.

Before deployment: replace mahgiiban0705@gmail.com, add your GitHub URL, add your CV as assets/resume/Mahgiiban-CV.pdf, and add real project screenshots. Deploy through GitHub Pages or Vercel.
